# Regression Test Gate Report

- **Verdict**: **PROMOTE**
- **Date**: 2026-11-16 04:19:31 UTC
- **Policy Version**: `1.0.0`
- **Baseline Artifact**: `200`
- **Candidate Artifact**: `197`

## Summary Statistics

| Metric | Value |
| :--- | :--- |
| **Baseline Pass Rate** | 0.0% |
| **Candidate Pass Rate** | 0.0% |
| **Delta Pass Rate** | +0.0% (95% CI [+0.0%, +0.0%]) |
| **Regressed Tests (b)** | 0 (Rate: 0.0%, 95% CI [+0.0%, +0.0%]) |
| **Fixed Tests (c)** | 0 (Rate: 0.0%) |
| **Unchanged Tests** | 0 |
| **Still Failing Tests** | 464 |
| **McNemar p-value** | 1.0000 |
| **Consistency** | 100.0% |


## Regressed Tests (Pass -> Fail)

None. No tests regressed.


## Secondary Slice View

| Slice Tag | Tests | Baseline Rate | Candidate Rate | Delta |
| :--- | :--- | :--- | :--- | :--- |
| `adversarial:False` | 125 | 0.0% | 0.0% | +0.0% |
| `adversarial:True` | 30 | 0.0% | 0.0% | +0.0% |
| `category:academia` | 4 | 0.0% | 0.0% | +0.0% |
| `category:aggregations` | 33 | 0.0% | 0.0% | +0.0% |
| `category:board_meetings` | 9 | 0.0% | 0.0% | +0.0% |
| `category:brevity_constraint` | 10 | 0.0% | 0.0% | +0.0% |
| `category:contracts` | 7 | 0.0% | 0.0% | +0.0% |
| `category:corporate` | 4 | 0.0% | 0.0% | +0.0% |
| `category:customer_support` | 4 | 0.0% | 0.0% | +0.0% |
| `category:deterministic_baseline` | 15 | 0.0% | 0.0% | +0.0% |
| `category:education` | 4 | 0.0% | 0.0% | +0.0% |
| `category:executive` | 5 | 0.0% | 0.0% | +0.0% |
| `category:extraction` | 15 | 0.0% | 0.0% | +0.0% |
| `category:extreme_length` | 10 | 0.0% | 0.0% | +0.0% |
| `category:filtering` | 8 | 0.0% | 0.0% | +0.0% |
| `category:finance` | 17 | 0.0% | 0.0% | +0.0% |
| `category:general` | 7 | 0.0% | 0.0% | +0.0% |
| `category:instruction_override` | 10 | 0.0% | 0.0% | +0.0% |
| `category:invoices` | 12 | 0.0% | 0.0% | +0.0% |
| `category:jailbreak_override` | 10 | 0.0% | 0.0% | +0.0% |
| `category:joins` | 6 | 0.0% | 0.0% | +0.0% |
| `category:json_strictness` | 10 | 0.0% | 0.0% | +0.0% |
| `category:legal` | 10 | 0.0% | 0.0% | +0.0% |
| `category:medical` | 9 | 0.0% | 0.0% | +0.0% |
| `category:missing_fields` | 10 | 0.0% | 0.0% | +0.0% |
| `category:news` | 4 | 0.0% | 0.0% | +0.0% |
| `category:pii_redaction` | 25 | 0.0% | 0.0% | +0.0% |
| `category:politics` | 4 | 0.0% | 0.0% | +0.0% |
| `category:prompt_leak` | 10 | 0.0% | 0.0% | +0.0% |
| `category:receipts` | 11 | 0.0% | 0.0% | +0.0% |
| `category:retail` | 4 | 0.0% | 0.0% | +0.0% |
| `category:science` | 7 | 0.0% | 0.0% | +0.0% |
| `category:social` | 5 | 0.0% | 0.0% | +0.0% |
| `category:standups` | 11 | 0.0% | 0.0% | +0.0% |
| `category:strategy` | 10 | 0.0% | 0.0% | +0.0% |
| `category:summarization` | 15 | 0.0% | 0.0% | +0.0% |
| `category:syntax` | 10 | 0.0% | 0.0% | +0.0% |
| `category:tech` | 20 | 0.0% | 0.0% | +0.0% |
| `category:typos` | 10 | 0.0% | 0.0% | +0.0% |
| `category:window_functions` | 3 | 0.0% | 0.0% | +0.0% |
| `contains_pii:True` | 25 | 0.0% | 0.0% | +0.0% |
| `difficulty:easy` | 83 | 0.0% | 0.0% | +0.0% |
| `difficulty:hard` | 61 | 0.0% | 0.0% | +0.0% |
| `difficulty:medium` | 126 | 0.0% | 0.0% | +0.0% |
| `edge_case:False` | 80 | 0.0% | 0.0% | +0.0% |
| `edge_case:True` | 10 | 0.0% | 0.0% | +0.0% |
| `edge_case:false` | 89 | 0.0% | 0.0% | +0.0% |
| `edge_case:true` | 41 | 0.0% | 0.0% | +0.0% |
| `family:consistency` | 15 | 0.0% | 0.0% | +0.0% |
| `family:fairness` | 30 | 0.0% | 0.0% | +0.0% |
| `family:functional` | 50 | 0.0% | 0.0% | +0.0% |
| `family:output_format` | 30 | 0.0% | 0.0% | +0.0% |
| `family:privacy` | 25 | 0.0% | 0.0% | +0.0% |
| `family:robustness` | 30 | 0.0% | 0.0% | +0.0% |
| `family:safety` | 30 | 0.0% | 0.0% | +0.0% |
| `is_inverse:false` | 11 | 0.0% | 0.0% | +0.0% |
| `is_inverse:true` | 11 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_01` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_02` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_03` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_04` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_05` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_06` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_07` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_08` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_09` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_10` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_11` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_12` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_13` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_14` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_id:pair_15` | 2 | 0.0% | 0.0% | +0.0% |
| `pair_type:demographic_names` | 10 | 0.0% | 0.0% | +0.0% |
| `pair_type:dialect_and_phrasing` | 8 | 0.0% | 0.0% | +0.0% |
| `pair_type:gender_and_demographic_names` | 10 | 0.0% | 0.0% | +0.0% |
| `pair_type:register_formality` | 2 | 0.0% | 0.0% | +0.0% |
| `rule:rule_empty_entities` | 2 | 0.0% | 0.0% | +0.0% |
| `rule:rule_entity_types` | 2 | 0.0% | 0.0% | +0.0% |
| `rule:rule_fact_density` | 2 | 0.0% | 0.0% | +0.0% |
| `rule:rule_json_structure` | 2 | 0.0% | 0.0% | +0.0% |
| `rule:rule_neutral_facts` | 2 | 0.0% | 0.0% | +0.0% |
| `rule:rule_no_filler` | 2 | 0.0% | 0.0% | +0.0% |
| `rule:rule_no_prelude` | 2 | 0.0% | 0.0% | +0.0% |
| `rule:rule_no_prose` | 2 | 0.0% | 0.0% | +0.0% |
| `rule:rule_no_punct` | 2 | 0.0% | 0.0% | +0.0% |
| `rule:rule_single_label` | 2 | 0.0% | 0.0% | +0.0% |
| `rule:rule_word_limit` | 2 | 0.0% | 0.0% | +0.0% |
| `slice_group:group_a` | 15 | 0.0% | 0.0% | +0.0% |
| `slice_group:group_b` | 15 | 0.0% | 0.0% | +0.0% |
